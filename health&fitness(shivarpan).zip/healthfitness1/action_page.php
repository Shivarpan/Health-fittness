
<html>
<head>
	<title> PHP Action Page </title>
</head>

	<body>
		<?php
        <p> This is a Paragraph </p>
	</body>

</html>
